export default function Page(){return <main style={{padding:24,fontFamily:'Arial'}}><h1>Support</h1><p>TODO: production page for support.</p></main>}
