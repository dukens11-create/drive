export default function Page(){return <main style={{padding:24,fontFamily:'Arial'}}><h1>Payments</h1><p>TODO: production page for payments.</p></main>}
