export default function Page(){return <main style={{padding:24,fontFamily:'Arial'}}><h1>Safety</h1><p>TODO: production page for safety.</p></main>}
