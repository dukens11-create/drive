export default function Page(){return <main style={{padding:24,fontFamily:'Arial'}}><h1>FlupFlap Dashboard V7</h1><p>Connect API and finish UI.</p></main>}
