export default function Page(){return <main style={{padding:24,fontFamily:'Arial'}}><h1>Risk</h1><p>TODO: production page for risk.</p></main>}
