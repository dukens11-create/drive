export default function Page(){return <main style={{padding:24,fontFamily:'Arial'}}><h1>Settings</h1><p>TODO: production page for settings.</p></main>}
