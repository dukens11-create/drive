export default function Page(){return <main style={{padding:24,fontFamily:'Arial'}}><h1>Users</h1><p>TODO: production page for users.</p></main>}
