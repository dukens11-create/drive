export default function Page(){return <main style={{padding:24,fontFamily:'Arial'}}><h1>Wallet</h1><p>TODO: production page for wallet.</p></main>}
