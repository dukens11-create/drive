export default function Page(){return <main style={{padding:24,fontFamily:'Arial'}}><h1>Drivers</h1><p>TODO: production page for drivers.</p></main>}
