export default function Page(){return <main style={{padding:24,fontFamily:'Arial'}}><h1>Products</h1><p>TODO: production page for products.</p></main>}
