export default function Page(){return <main style={{padding:24,fontFamily:'Arial'}}><h1>Payouts</h1><p>TODO: production page for payouts.</p></main>}
