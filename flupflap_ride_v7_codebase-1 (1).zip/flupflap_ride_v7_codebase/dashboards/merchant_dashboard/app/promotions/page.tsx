export default function Page(){return <main style={{padding:24,fontFamily:'Arial'}}><h1>Promotions</h1><p>TODO: production page for promotions.</p></main>}
