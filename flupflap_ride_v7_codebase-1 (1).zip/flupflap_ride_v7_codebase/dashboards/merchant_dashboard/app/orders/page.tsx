export default function Page(){return <main style={{padding:24,fontFamily:'Arial'}}><h1>Orders</h1><p>TODO: production page for orders.</p></main>}
