export default function Page(){return <main style={{padding:24,fontFamily:'Arial'}}><h1>Analytics</h1><p>TODO: production page for analytics.</p></main>}
