export default function Page(){return <main style={{padding:24,fontFamily:'Arial'}}><h1>Delivery</h1><p>TODO: production page for delivery.</p></main>}
