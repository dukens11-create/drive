export function calculateFare(input: { miles?: number; minutes?: number; surge?: number }) {
  const base = 275;
  const perMile = 190;
  const perMinute = 38;
  const platformMin = 99;
  const miles = input.miles ?? 3;
  const minutes = input.minutes ?? 10;
  const surge = input.surge ?? 1;
  const subtotal = Math.round((base + miles * perMile + minutes * perMinute) * surge);
  return {
    subtotalCents: subtotal,
    platformFeeCents: platformMin,
    totalCents: subtotal + platformMin,
    currency: 'USD'
  };
}
