import http from 'k6/http';
import { sleep } from 'k6';
export const options = { vus: 100, duration: '2m' };
export default function () {
  http.post('http://localhost:8080/api/rides/estimate', JSON.stringify({ miles: 3, minutes: 10 }), { headers: { 'Content-Type': 'application/json' } });
  sleep(1);
}
