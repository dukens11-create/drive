import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiClient {
  final String baseUrl;
  ApiClient({this.baseUrl = 'http://localhost:8080/api'});
  Future<Map<String,dynamic>> post(String path, Map<String,dynamic> body) async {
    final res = await http.post(Uri.parse('$baseUrl$path'), headers:{'Content-Type':'application/json'}, body:jsonEncode(body));
    return jsonDecode(res.body) as Map<String,dynamic>;
  }
}
