import 'package:flutter/material.dart';
import 'screens/login_screen.dart';
void main() => runApp(const App());
class App extends StatelessWidget {
  const App({super.key});
  @override Widget build(BuildContext context) => MaterialApp(
    title: 'FlupFlap Ride',
    theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.orange),
    home: const LoginScreen(),
  );
}
