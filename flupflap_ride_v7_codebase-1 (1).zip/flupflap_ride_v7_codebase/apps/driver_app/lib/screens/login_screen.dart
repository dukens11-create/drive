import 'package:flutter/material.dart';
import 'home_screen.dart';
class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});
  @override Widget build(BuildContext context)=>Scaffold(
    appBar: AppBar(title: const Text('FlupFlap Ride Login')),
    body: Padding(padding: const EdgeInsets.all(16), child: Column(children:[
      const TextField(decoration: InputDecoration(labelText:'Email or phone')),
      const TextField(decoration: InputDecoration(labelText:'Password'), obscureText:true),
      const SizedBox(height:16),
      ElevatedButton(onPressed:()=>Navigator.pushReplacement(context, MaterialPageRoute(builder:(_)=>const HomeScreen())), child: const Text('Continue'))
    ])),
  );
}
