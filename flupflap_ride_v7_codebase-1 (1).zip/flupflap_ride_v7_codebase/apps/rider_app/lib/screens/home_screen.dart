import 'package:flutter/material.dart';
import 'ride_screen.dart';
import 'delivery_screen.dart';
import 'wallet_screen.dart';
import 'profile_screen.dart';
class HomeScreen extends StatefulWidget { const HomeScreen({super.key}); @override State<HomeScreen> createState()=>_HomeScreenState(); }
class _HomeScreenState extends State<HomeScreen> {
 int i=0; final pages=const [RideScreen(),DeliveryScreen(),WalletScreen(),ProfileScreen()];
 @override Widget build(BuildContext context)=>Scaffold(body:pages[i],bottomNavigationBar:BottomNavigationBar(currentIndex:i,onTap:(v)=>setState(()=>i=v),items:const[
  BottomNavigationBarItem(icon:Icon(Icons.local_taxi),label:'Ride'),
  BottomNavigationBarItem(icon:Icon(Icons.delivery_dining),label:'Delivery'),
  BottomNavigationBarItem(icon:Icon(Icons.wallet),label:'Wallet'),
  BottomNavigationBarItem(icon:Icon(Icons.person),label:'Profile'),
 ]));
}
